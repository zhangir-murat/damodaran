# Valuation workbench

Interactive rebuilds of Aswath Damodaran's (NYU Stern) valuation data and website.

| # | Page | Where it lives |
|---|------|----------------|
| 1 | EV multiples by industry (US, Jan 2026) | Claude artifact (linked from the home page) |
| 2 | Damodaran Online, rebuilt | [`/damodaran`](./damodaran/) in this repo |
| 3 | Country risk premiums (Jan 2026) | Claude artifact (linked from the home page) |

`index.html` is the home page with the sideways-scrolling menu.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

## Publish with GitHub Pages

Settings → Pages → Source: **Deploy from a branch** → `main` / `(root)`.

## Credits

All data, classes, papers and files belong to Aswath Damodaran and link back to
[his NYU Stern site](https://pages.stern.nyu.edu/~adamodar/). This is an unofficial redesign.
